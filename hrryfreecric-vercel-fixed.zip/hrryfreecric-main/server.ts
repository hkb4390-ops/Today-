import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// In-memory token cache to minimize upstream requests
let cachedTokenData: { token: string; expiresAt: number; ipTag: string } = {
  token: '970273a95d37ebdb72766e1c1ee1c70c16570997784f7e1nd5bdcde1058a46ee1c68e8e288b67c5845d7bf4010d2a27d9964a7a76d598752bde193e15037cef47',
  expiresAt: 1791572400,
  ipTag: '0a50c00f7202e596',
};
let lastTokenFetchTime = 0;

async function fetchFreshToken() {
  const now = Date.now();
  if (now - lastTokenFetchTime < 300000) {
    return cachedTokenData;
  }

  try {
    const res = await fetch('https://smartcric.is/token.php', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko)',
        'Accept': 'application/json, text/plain, */*'
      }
    });
    if (res.ok) {
      const json = await res.json();
      if (json && typeof json.token === 'string' && json.token.length > 80) {
        cachedTokenData = {
          token: json.token,
          expiresAt: json.expiresAt || Math.floor(Date.now() / 1000) + 86400,
          ipTag: json.ipTag || 'live'
        };
        lastTokenFetchTime = now;
        return cachedTokenData;
      }
    }
  } catch (err) {
    console.warn('Direct token.php fetch failed:', err);
  }

  return cachedTokenData;
}

// API endpoint for streaming token
app.get('/api/token', async (req, res) => {
  try {
    const token = await fetchFreshToken();
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'no-cache');
    res.json(token);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Token retrieval failed' });
  }
});

// API endpoint for real channels list
app.get('/api/channels/:sn?', async (req, res) => {
  const sn = req.params.sn || '8cdR-LEJ8-U3FP-X6bc-6a3gc';
  try {
    const upstreamUrl = `https://rest.smartcric.stream/mobile/channels/live/${encodeURIComponent(sn)}`;
    const apiRes = await fetch(upstreamUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko)',
        'Accept': 'application/json'
      }
    });

    if (!apiRes.ok) {
      return res.status(apiRes.status).json({ error: `Upstream returned status ${apiRes.status}` });
    }

    const data = await apiRes.json();
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'no-cache');
    res.json(data);
  } catch (error: any) {
    res.status(502).json({ error: error.message || 'Failed to fetch upstream live channels' });
  }
});

/**
 * Universal Stream Proxy Route (`/api/stream` and subpaths)
 * Bypasses all ISP blocks (Jio/Airtel/Vi) and CORS restrictions.
 */
app.all(['/api/stream', '/api/stream/master.m3u8', '/api/stream/child.m3u8', '/api/stream/segment.ts'], async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const mode = req.query.mode as string;
  const target = req.query.target as string;
  const host = (req.query.host as string) || '63.scjustfor.info';
  const stream = req.query.stream as string;
  const id = req.query.id as string;
  const pk = req.query.pk as string;

  // 1. TS video segment proxy
  if (mode === 'segment' || req.path.endsWith('segment.ts') || (target && (target.includes('.ts?') || target.endsWith('.ts')))) {
    if (!target) return res.status(400).send('Missing segment target');
    try {
      const upstreamRes = await fetch(target, {
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });
      if (!upstreamRes.ok) return res.status(upstreamRes.status).send('Segment fetch error');

      res.setHeader('Content-Type', 'video/MP2T');
      res.setHeader('Cache-Control', 'public, max-age=3600');
      const arrayBuffer = await upstreamRes.arrayBuffer();
      return res.status(200).send(Buffer.from(arrayBuffer));
    } catch (err: any) {
      return res.status(502).send(err.message);
    }
  }

  // 2. Child playlist proxy
  if (mode === 'child' || req.path.endsWith('child.m3u8') || (target && target.includes('.m3u8'))) {
    if (!target) return res.status(400).send('Missing playlist target');
    try {
      const upstreamRes = await fetch(target, {
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });
      if (!upstreamRes.ok) return res.status(upstreamRes.status).send('Child playlist fetch error');

      const playlistText = await upstreamRes.text();
      const basePath = target.substring(0, target.lastIndexOf('/') + 1);

      const rewritten = playlistText.split('\n').map((line) => {
        const trimmed = line.trim();
        if (trimmed && !trimmed.startsWith('#')) {
          const fullTsUrl = trimmed.startsWith('http') ? trimmed : `${basePath}${trimmed}`;
          return `/api/stream?mode=segment&target=${encodeURIComponent(fullTsUrl)}`;
        }
        return line;
      }).join('\n');

      res.setHeader('Content-Type', 'application/vnd.apple.mpegurl; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache');
      return res.status(200).send(rewritten);
    } catch (err: any) {
      return res.status(502).send(err.message);
    }
  }

  // 3. Master playlist proxy
  if (mode === 'master' || req.path.endsWith('master.m3u8') || (stream && id && pk)) {
    const upstreamUrl = `https://${host}/mobile/${stream}/playlist.m3u8?id=${id}&pk=${pk}`;
    try {
      const upstreamRes = await fetch(upstreamUrl, {
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });
      if (!upstreamRes.ok) return res.status(upstreamRes.status).send('Master playlist fetch error');

      const playlistText = await upstreamRes.text();
      const rewritten = playlistText.split('\n').map((line) => {
        const trimmed = line.trim();
        if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
          return `/api/stream?mode=child&target=${encodeURIComponent(trimmed)}`;
        }
        return line;
      }).join('\n');

      res.setHeader('Content-Type', 'application/vnd.apple.mpegurl; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache');
      return res.status(200).send(rewritten);
    } catch (err: any) {
      return res.status(502).send(err.message);
    }
  }

  return res.status(400).send('Invalid stream request');
});

// Static / Vite middleware
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CRICHRRY server active at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
