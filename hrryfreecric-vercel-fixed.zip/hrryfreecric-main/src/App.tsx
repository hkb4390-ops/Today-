import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { ChannelItem, TokenResponse } from './types/cricket';
import { 
  DEFAULT_SN, 
  fetchChannelsList, 
  fetchStreamingToken, 
  isChannelLive 
} from './services/streamingApi';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { LiveNowSection } from './components/LiveNowSection';
import { ChannelsGrid } from './components/ChannelsGrid';
import { PlayerModal } from './components/PlayerModal';
import { OfflineModal } from './components/OfflineModal';
import { BottomNav } from './components/BottomNav';
import { isSoundEnabled, setSoundEnabled, playPopSound, playTapSound } from './utils/audio';
import { AlertCircle, RefreshCw } from 'lucide-react';

// Legitimate channel initial state to ensure instant hydration
const INITIAL_CHANNELS: ChannelItem[] = [
  {
    channelId: 3,
    caption: 'Australia Vs South Africa',
    active: 1,
    channelName: 'Live Match',
    fmsUrl: '63.scjustfor.info',
    status: '1',
    streamsList: [
      { caption: 'Low', streamId: 9, streamName: 'stream3_160p' },
      { caption: 'Medium', streamId: 10, streamName: 'stream3_240p' },
      { caption: 'High', streamId: 11, streamName: 'stream3_320p' },
    ],
  },
  {
    channelId: 4,
    caption: 'Afghanistan Vs Bangladesh',
    active: 1,
    channelName: 'Live Match',
    fmsUrl: '63.scjustfor.info',
    status: '1',
    streamsList: [
      { caption: 'Low', streamId: 13, streamName: 'stream4_160p' },
      { caption: 'Medium', streamId: 14, streamName: 'stream4_240p' },
      { caption: 'High', streamId: 15, streamName: 'stream4_320p' },
    ],
  },
  {
    channelId: 1,
    caption: 'India Vs West Indies',
    active: 0,
    channelName: 'No live match at the moment',
    fmsUrl: '63.scjustfor.info',
    status: '1',
  },
  {
    channelId: 2,
    caption: 'England Vs Sri Lanka',
    active: 0,
    channelName: 'No live match at the moment',
    fmsUrl: '63.scjustfor.info',
    status: '1',
  },
  {
    channelId: 5,
    caption: "Women's Big Bash, 2026",
    active: 0,
    channelName: 'No live match at the moment',
    fmsUrl: '63.scjustfor.info',
    status: '1',
  },
  {
    channelId: 6,
    caption: 'Asian Games, 2026',
    active: 0,
    channelName: 'No live match at the moment',
    fmsUrl: '63.scjustfor.info',
    status: '1',
  },
];

export default function App() {
  const [channels, setChannels] = useState<ChannelItem[]>(INITIAL_CHANNELS);
  const [tokenData, setTokenData] = useState<TokenResponse | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [apiError, setApiError] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'streams' | 'all'>('streams');
  const [soundActive, setSoundActive] = useState<boolean>(isSoundEnabled());

  // Active playback state
  const [playerChannel, setPlayerChannel] = useState<ChannelItem | null>(null);
  const [playerStreamIdx, setPlayerStreamIdx] = useState<number>(0);

  // Active offline info modal
  const [offlineModalChannel, setOfflineModalChannel] = useState<ChannelItem | null>(null);

  const toggleSound = () => {
    const nextState = !soundActive;
    setSoundActive(nextState);
    setSoundEnabled(nextState);
  };

  // Load streaming session token
  const loadToken = useCallback(async (): Promise<string> => {
    try {
      const data = await fetchStreamingToken();
      setTokenData(data);
      return data.token;
    } catch {
      return tokenData?.token || '';
    }
  }, [tokenData?.token]);

  // Load real channel data from the live API
  const loadChannels = useCallback(async (isBackground: boolean = false) => {
    if (isBackground) {
      setIsRefreshing(true);
    }

    try {
      const [channelsData, tokenResult] = await Promise.all([
        fetchChannelsList(DEFAULT_SN),
        fetchStreamingToken().catch(() => null),
      ]);

      if (tokenResult) {
        setTokenData(tokenResult);
      }

      if (channelsData && Array.isArray(channelsData.channelsList) && channelsData.channelsList.length > 0) {
        setChannels(channelsData.channelsList);
      }
      setApiError(null);
    } catch (err: any) {
      console.warn('Background sync error:', err.message);
      if (!channels.length) {
        setApiError('Unable to connect to live stream server.');
      }
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [channels.length]);

  // Immediate fetch on mount
  useEffect(() => {
    loadChannels(false);
  }, []);

  // Periodic polling interval (every 25 seconds to catch new stream links)
  useEffect(() => {
    const interval = setInterval(() => {
      loadChannels(true);
    }, 25000);
    return () => clearInterval(interval);
  }, [loadChannels]);

  // Filter real live channels (any channel with active streamsList or active: 1)
  const liveChannels = useMemo(() => {
    return channels.filter(isChannelLive);
  }, [channels]);

  const handleWatchChannel = (channel: ChannelItem, streamIdx: number = 0) => {
    playPopSound();
    setPlayerChannel(channel);
    setPlayerStreamIdx(streamIdx);
  };

  return (
    <div className="min-h-screen bg-[#030509] text-slate-100 flex flex-col relative overflow-x-hidden selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* iOS 2027 Ambient Background Glows */}
      <div className="glow-orb-cyan top-0 left-1/4 w-[450px] h-[450px] opacity-25" />
      <div className="glow-orb-purple top-1/3 right-10 w-[500px] h-[500px] opacity-20" />

      {/* Floating Header */}
      <Header
        activeLiveCount={liveChannels.length}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        soundEnabled={soundActive}
        onToggleSound={toggleSound}
      />

      {/* Main Content */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 pt-2 pb-24 md:pb-12 z-10">
        
        {/* Loading State if no channels */}
        {isLoading && channels.length === 0 && (
          <div className="space-y-6 pt-4 animate-pulse">
            <div className="h-64 sm:h-80 rounded-4xl bg-white/[0.03] border border-white/5" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-44 rounded-3xl bg-white/[0.03] border border-white/5" />
              ))}
            </div>
          </div>
        )}

        {/* Error State only if zero channels */}
        {!isLoading && apiError && channels.length === 0 && (
          <div className="my-16 p-8 sm:p-10 rounded-4xl liquid-glass text-center max-w-sm mx-auto shadow-2xl">
            <div className="p-3.5 rounded-2xl bg-red-500/15 border border-red-500/30 text-red-400 w-fit mx-auto mb-3">
              <AlertCircle className="w-7 h-7" />
            </div>
            <h2 className="text-lg font-black text-white mb-1.5">
              Unable to load live streams
            </h2>
            <p className="text-xs text-slate-400 mb-5">
              Please check your connection and tap retry.
            </p>
            <button
              onClick={() => {
                playTapSound();
                loadChannels(false);
              }}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold text-xs uppercase tracking-wider active:scale-95 transition-all"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry</span>
            </button>
          </div>
        )}

        {/* Normal Content */}
        {channels.length > 0 && (
          <>
            {activeTab === 'streams' ? (
              <>
                <HeroBanner
                  liveChannels={liveChannels}
                  onWatchChannel={handleWatchChannel}
                  onExploreFeeds={() => setActiveTab('all')}
                />

                <LiveNowSection
                  liveChannels={liveChannels}
                  onWatchChannel={handleWatchChannel}
                  onExploreFeeds={() => setActiveTab('all')}
                />

                <div className="mt-8 pt-8 border-t border-white/[0.08]">
                  <ChannelsGrid
                    channels={channels}
                    onSelectChannel={handleWatchChannel}
                    onShowOfflineCard={(ch) => setOfflineModalChannel(ch)}
                    searchQuery={searchQuery}
                    onSearchChange={setSearchQuery}
                  />
                </div>
              </>
            ) : (
              <ChannelsGrid
                channels={channels}
                onSelectChannel={handleWatchChannel}
                onShowOfflineCard={(ch) => setOfflineModalChannel(ch)}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
              />
            )}
          </>
        )}

      </main>

      {/* Minimal iOS Footer */}
      <footer className="py-6 px-4 text-center text-xs text-slate-500 z-10 border-t border-white/[0.04]">
        <div className="flex items-center justify-center gap-2">
          <img
            src="https://i.postimg.cc/Dz1FXztx/file-00000000112082088dbc45fc024a2c70.png"
            alt="CRICHRRY"
            className="h-5 w-auto object-contain opacity-60"
          />
          <span className="font-semibold text-slate-400">CRICHRRY</span>
          <span>·</span>
          <span>Real Live Cricket</span>
        </div>
      </footer>

      {/* Floating Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeLiveCount={liveChannels.length}
        onRefresh={() => loadChannels(true)}
        isRefreshing={isRefreshing}
        soundEnabled={soundActive}
        onToggleSound={toggleSound}
      />

      {/* Cinematic Player */}
      {playerChannel && (
        <PlayerModal
          channel={playerChannel}
          initialStreamIndex={playerStreamIdx}
          token={tokenData?.token || '970273a95d37ebdb72766e1c1ee1c70c16570997784f7e1nd5bdcde1058a46ee1c68e8e288b67c5845d7bf4010d2a27d9964a7a76d598752bde193e15037cef47'}
          onClose={() => setPlayerChannel(null)}
          onRefreshToken={loadToken}
        />
      )}

      {/* Offline Modal */}
      {offlineModalChannel && (
        <OfflineModal
          channel={offlineModalChannel}
          onClose={() => setOfflineModalChannel(null)}
        />
      )}

    </div>
  );
}
