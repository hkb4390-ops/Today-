import React from 'react';
import { Radio, Tv, RefreshCw, Volume2, VolumeX } from 'lucide-react';
import { playTapSound } from '../utils/audio';

interface BottomNavProps {
  activeTab: 'streams' | 'all';
  setActiveTab: (tab: 'streams' | 'all') => void;
  activeLiveCount: number;
  onRefresh: () => void;
  isRefreshing: boolean;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  activeLiveCount,
  onRefresh,
  isRefreshing,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 md:hidden pb-safe pointer-events-none">
      <div className="mx-4 mb-3 p-1.5 rounded-3xl liquid-glass shadow-2xl flex items-center justify-around pointer-events-auto">
        {/* Live */}
        <button
          onClick={() => {
            playTapSound();
            setActiveTab('streams');
          }}
          className={`flex items-center gap-1.5 py-2 px-4 rounded-2xl transition-all duration-300 ${
            activeTab === 'streams'
              ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <div className="relative">
            <Radio className="w-4 h-4" />
            {activeLiveCount > 0 && (
              <span className="absolute -top-1 -right-1.5 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-80" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500" />
              </span>
            )}
          </div>
          <span className="text-xs">Live</span>
        </button>

        {/* Channels */}
        <button
          onClick={() => {
            playTapSound();
            setActiveTab('all');
          }}
          className={`flex items-center gap-1.5 py-2 px-4 rounded-2xl transition-all duration-300 ${
            activeTab === 'all'
              ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold shadow-md'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Tv className="w-4 h-4" />
          <span className="text-xs">Channels</span>
        </button>

        {/* Refresh */}
        <button
          onClick={() => {
            playTapSound();
            onRefresh();
          }}
          disabled={isRefreshing}
          className="p-2.5 rounded-2xl text-slate-400 hover:text-white transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-cyan-400' : ''}`} />
        </button>

        {/* Sound */}
        <button
          onClick={() => {
            onToggleSound();
            playTapSound();
          }}
          className={`p-2.5 rounded-2xl transition-all ${
            soundEnabled ? 'text-cyan-400' : 'text-slate-500'
          }`}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};
