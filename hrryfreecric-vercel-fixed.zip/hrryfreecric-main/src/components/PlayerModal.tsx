import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import { ChannelItem, StreamItem } from '../types/cricket';
import { buildStreamUrl, buildStreamProxyUrl, computeJako } from '../services/streamingApi';
import { 
  ArrowLeft, 
  Maximize, 
  Minimize, 
  RefreshCw, 
  Volume2, 
  VolumeX, 
  Play, 
  Pause, 
  AlertTriangle,
  Radio
} from 'lucide-react';
import { playDismissSound, playStreamStartSound, playTapSound } from '../utils/audio';

interface PlayerModalProps {
  channel: ChannelItem;
  initialStreamIndex?: number;
  token: string;
  onClose: () => void;
  onRefreshToken: () => Promise<string>;
}

export const PlayerModal: React.FC<PlayerModalProps> = ({
  channel,
  initialStreamIndex = 0,
  token,
  onClose,
  onRefreshToken,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const hlsRef = useRef<Hls | null>(null);

  const [streamIndex, setStreamIndex] = useState(initialStreamIndex);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isBuffering, setIsBuffering] = useState(true);
  const [needsTapForAudio, setNeedsTapForAudio] = useState(false);
  const [errorState, setErrorState] = useState<string | null>(null);
  const [errorDetail, setErrorDetail] = useState<string | null>(null);
  const [retryTrigger, setRetryTrigger] = useState(0);

  const streams: StreamItem[] = channel.streamsList && channel.streamsList.length > 0
    ? channel.streamsList
    : [{ streamName: `stream${channel.channelId}_160p`, streamId: channel.channelId, caption: 'Standard' }];

  const currentStream = streams[streamIndex] || streams[0];

  // Primary Player Lifecycle: ONLY runs when channel or streamIndex or retryTrigger changes
  useEffect(() => {
    let isMounted = true;
    const video = videoRef.current;
    if (!video) return;

    // Destroy any existing HLS instance before initializing
    if (hlsRef.current) {
      try {
        hlsRef.current.destroy();
      } catch {}
      hlsRef.current = null;
    }

    try {
      video.pause();
      video.removeAttribute('src');
      video.load();
    } catch {}

    setIsBuffering(true);
    setErrorState(null);
    setErrorDetail(null);
    setNeedsTapForAudio(false);

    // Use stream proxy by default to bypass ISP blocking (Jio/Airtel) on *.scjustfor.info
    const host = channel.fmsUrl || '63.scjustfor.info';
    const streamName = currentStream.streamName;
    const streamId = currentStream.streamId;
    const streamUrl = buildStreamProxyUrl(host, streamName, streamId, token);

    // Safety fallback: dismiss buffering overlay after 3 seconds
    const safetyTimer = setTimeout(() => {
      if (isMounted) setIsBuffering(false);
    }, 3000);

    const onMediaStarted = () => {
      if (!isMounted) return;
      clearTimeout(safetyTimer);
      setIsBuffering(false);
      setIsPlaying(true);
    };

    video.onplaying = onMediaStarted;
    video.onloadeddata = () => {
      if (isMounted) setIsBuffering(false);
    };
    video.oncanplay = () => {
      if (isMounted) setIsBuffering(false);
    };
    video.ontimeupdate = () => {
      if (video.currentTime > 0) onMediaStarted();
    };

    if (Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: false, // Prevents blob worker sandbox crashes on Vercel / sandboxed environments
        lowLatencyMode: true,
        backBufferLength: 60,
        manifestLoadingTimeOut: 15000,
        manifestLoadingMaxRetry: 2,
        fragLoadingTimeOut: 15000,
        fragLoadingMaxRetry: 3,
      });

      hlsRef.current = hls;

      hls.on(Hls.Events.MEDIA_ATTACHED, () => {
        hls.loadSource(streamUrl);
      });

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        if (!isMounted) return;
        setIsBuffering(false);
        playStreamStartSound();

        // Autoplay attempt: try with audio first
        video.muted = false;
        const playPromise = video.play();
        if (playPromise) {
          playPromise
            .then(() => {
              if (isMounted) {
                setIsPlaying(true);
                setIsMuted(false);
              }
            })
            .catch(() => {
              // Browser blocked unmuted autoplay: start muted and prompt user to unmute
              if (!isMounted) return;
              video.muted = true;
              setIsMuted(true);
              video.play()
                .then(() => {
                  if (isMounted) {
                    setIsPlaying(true);
                    setNeedsTapForAudio(true);
                  }
                })
                .catch(() => {
                  if (isMounted) {
                    setIsPlaying(false);
                    setNeedsTapForAudio(true);
                  }
                });
            });
        }
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (!isMounted) return;
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              try {
                hls.startLoad();
              } catch {
                setIsBuffering(false);
                setErrorState('STREAM UNAVAILABLE');
                setErrorDetail('Network connection error. Tap Reconnect to retry.');
              }
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              try {
                hls.recoverMediaError();
              } catch {
                setIsBuffering(false);
                setErrorState('STREAM UNAVAILABLE');
                setErrorDetail('Media decode error. Tap Reconnect to retry.');
              }
              break;
            default:
              setIsBuffering(false);
              setErrorState('STREAM UNAVAILABLE');
              setErrorDetail('The stream is currently unreachable. Tap Reconnect.');
              break;
          }
        }
      });

      hls.attachMedia(video);
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native iOS Safari HLS
      video.src = streamUrl;
      video.addEventListener('loadedmetadata', () => {
        if (!isMounted) return;
        clearTimeout(safetyTimer);
        setIsBuffering(false);
        playStreamStartSound();
        video.play().catch(() => {
          video.muted = true;
          setIsMuted(true);
          video.play().then(() => {
            if (isMounted) {
              setIsPlaying(true);
              setNeedsTapForAudio(true);
            }
          }).catch(() => {
            if (isMounted) setNeedsTapForAudio(true);
          });
        });
      }, { once: true });

      video.addEventListener('error', () => {
        if (!isMounted) return;
        clearTimeout(safetyTimer);
        setIsBuffering(false);
        setErrorState('STREAM UNAVAILABLE');
        setErrorDetail('Please try another stream quality.');
      }, { once: true });
    }

    return () => {
      isMounted = false;
      clearTimeout(safetyTimer);
      if (hlsRef.current) {
        try {
          hlsRef.current.destroy();
        } catch {}
        hlsRef.current = null;
      }
      try {
        video.pause();
        video.removeAttribute('src');
      } catch {}
    };
  }, [channel.channelId, streamIndex, retryTrigger]);

  const handleUnmuteOrPlay = () => {
    playTapSound();
    const video = videoRef.current;
    if (!video) return;
    video.muted = false;
    setIsMuted(false);
    setNeedsTapForAudio(false);
    video.play().then(() => setIsPlaying(true)).catch(() => {});
  };

  const togglePlay = () => {
    playTapSound();
    const video = videoRef.current;
    if (!video) return;
    if (needsTapForAudio) {
      handleUnmuteOrPlay();
      return;
    }
    if (video.paused) {
      video.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    playTapSound();
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setIsMuted(video.muted);
    setNeedsTapForAudio(false);
  };

  const toggleFullscreen = () => {
    playTapSound();
    const el = containerRef.current;
    if (!el) return;

    if (!document.fullscreenElement) {
      el.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const handleQualityChange = (index: number) => {
    playTapSound();
    if (index === streamIndex) return;
    setStreamIndex(index);
  };

  const handleRetry = async () => {
    playTapSound();
    try {
      await onRefreshToken();
    } catch {}
    setRetryTrigger((prev) => prev + 1);
  };

  const handleClose = () => {
    playDismissSound();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-2xl animate-in fade-in duration-300">
      <div 
        ref={containerRef}
        className="relative w-full h-full max-w-5xl max-h-[92vh] sm:rounded-4xl bg-black border border-white/10 flex flex-col justify-between overflow-hidden shadow-2xl"
      >
        {/* iOS Top Bar */}
        <div className="z-20 flex items-center justify-between p-4 sm:p-5 bg-gradient-to-b from-black/90 via-black/40 to-transparent">
          <div className="flex items-center gap-3">
            <button
              onClick={handleClose}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-white/[0.08] hover:bg-white/[0.15] text-white text-xs font-bold active:scale-95 transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm sm:text-base font-black text-white tracking-tight">
                  {channel.caption}
                </span>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-[10px] font-bold border border-red-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 ios-live-indicator" />
                  LIVE
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={toggleFullscreen}
            className="p-2.5 rounded-2xl bg-white/[0.08] hover:bg-white/[0.15] text-white active:scale-95 transition-all"
          >
            {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </button>
        </div>

        {/* Video Viewport */}
        <div className="relative flex-1 flex items-center justify-center bg-black overflow-hidden">
          {/* Ambient Video Glow */}
          <div className="glow-orb-cyan top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 opacity-40 pointer-events-none" />

          <video
            ref={videoRef}
            playsInline
            webkit-playsinline=""
            autoPlay
            controls
            className="w-full h-full max-h-[75vh] object-contain cursor-pointer z-10"
            onClick={togglePlay}
          />

          {/* Tap to Unmute / Tap to Play Floating Action */}
          {needsTapForAudio && !errorState && (
            <div 
              onClick={handleUnmuteOrPlay}
              className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/40 backdrop-blur-xs cursor-pointer select-none"
            >
              <div className="p-5 sm:p-6 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 text-black shadow-2xl shadow-cyan-400/50 hover:scale-105 active:scale-95 transition-all">
                <Play className="w-8 h-8 sm:w-10 sm:h-10 fill-black" />
              </div>
              <p className="mt-4 text-xs sm:text-sm font-extrabold text-white tracking-wider uppercase px-4 py-1.5 rounded-full bg-black/70 border border-white/10">
                {isMuted ? 'Tap for Sound 🔊' : 'Tap to Play Stream'}
              </p>
            </div>
          )}

          {/* Buffering Spinner */}
          {isBuffering && !needsTapForAudio && !errorState && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/60 backdrop-blur-xs gap-3 pointer-events-none">
              <div className="w-12 h-12 rounded-full border-2 border-cyan-400/20 border-t-cyan-400 animate-spin" />
              <p className="text-xs font-semibold text-slate-300">
                Connecting to live stream...
              </p>
            </div>
          )}

          {/* Stream Error Notice */}
          {errorState && (
            <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-black/90 p-6 text-center gap-3.5">
              <div className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
                <AlertTriangle className="w-7 h-7" />
              </div>

              <div>
                <h3 className="text-base font-black text-white">
                  {errorState}
                </h3>
                <p className="text-xs text-slate-400 mt-1 max-w-xs">
                  {errorDetail || 'Please try another stream quality or reconnect.'}
                </p>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={handleRetry}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold text-xs uppercase tracking-wider active:scale-95 transition-all"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reconnect</span>
                </button>

                <button
                  onClick={handleClose}
                  className="px-5 py-2.5 rounded-2xl bg-white/[0.08] hover:bg-white/[0.15] text-white font-bold text-xs active:scale-95 transition-all"
                >
                  Close
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Floating iOS Bottom Bar */}
        <div className="z-20 p-4 sm:p-5 bg-gradient-to-t from-black/95 via-black/60 to-transparent flex items-center justify-between gap-3">
          {/* Play/Pause & Mute */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={togglePlay}
              className="p-3 rounded-2xl bg-white/[0.08] hover:bg-white/[0.15] text-white active:scale-95 transition-all"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
            </button>

            <button
              onClick={toggleMute}
              className="p-3 rounded-2xl bg-white/[0.08] hover:bg-white/[0.15] text-white active:scale-95 transition-all"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>

          {/* Quality Picker */}
          {streams.length > 1 && (
            <div className="flex items-center gap-1 p-1 rounded-2xl bg-white/[0.06] border border-white/10 text-xs font-semibold">
              {streams.map((st, idx) => (
                <button
                  key={idx}
                  onClick={() => handleQualityChange(idx)}
                  className={`px-3 py-1 rounded-xl transition-all ${
                    idx === streamIndex
                      ? 'bg-cyan-400 text-black font-extrabold shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {(st.caption || `Quality ${idx + 1}`).trim()}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
