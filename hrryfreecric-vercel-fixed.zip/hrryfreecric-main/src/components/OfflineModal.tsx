import React from 'react';
import { ChannelItem } from '../types/cricket';
import { Clock, X } from 'lucide-react';
import { playDismissSound, playTapSound } from '../utils/audio';

interface OfflineModalProps {
  channel: ChannelItem | null;
  onClose: () => void;
}

export const OfflineModal: React.FC<OfflineModalProps> = ({ channel, onClose }) => {
  if (!channel) return null;

  const handleClose = () => {
    playDismissSound();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-sm rounded-4xl liquid-glass-elevated p-6 sm:p-7 shadow-2xl overflow-hidden"
        role="dialog"
      >
        {/* Glow */}
        <div className="glow-orb-cyan top-[-60px] right-[-60px] w-48 h-48 opacity-40" />

        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/[0.06] hover:bg-white/[0.12] text-slate-400 hover:text-white transition-all active:scale-95"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Icon & Title */}
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider">
              Upcoming Match
            </span>
            <div className="text-xs text-slate-400">
              Channel {channel.channelId}
            </div>
          </div>
        </div>

        <h3 className="text-lg font-black text-white mb-2 leading-snug">
          {channel.caption}
        </h3>

        <div className="p-4 rounded-2xl bg-black/40 border border-white/5 mb-6 space-y-1.5">
          <p className="text-xs font-semibold text-slate-200">
            This match isn't live yet. Check back closer to the start.
          </p>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            The stream player unlocks automatically when live coverage begins.
          </p>
        </div>

        <button
          onClick={handleClose}
          className="w-full py-3 px-4 rounded-2xl bg-white/[0.08] hover:bg-white/[0.15] text-white font-bold text-xs uppercase tracking-wider active:scale-95 transition-all"
        >
          Got It
        </button>
      </div>
    </div>
  );
};
