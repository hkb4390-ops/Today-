import React from 'react';
import { ChannelItem } from '../types/cricket';
import { Play, Radio, WifiOff, Sparkles, Tv2, ArrowRight } from 'lucide-react';
import { playPopSound, playTapSound } from '../utils/audio';

interface HeroBannerProps {
  liveChannels: ChannelItem[];
  onWatchChannel: (channel: ChannelItem, streamIdx?: number) => void;
  onExploreFeeds: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  liveChannels,
  onWatchChannel,
  onExploreFeeds,
}) => {
  const hasLiveMatch = liveChannels.length > 0;
  const primaryLiveMatch = hasLiveMatch ? liveChannels[0] : null;

  return (
    <div className="relative overflow-hidden rounded-3xl sm:rounded-4xl liquid-glass-elevated p-6 sm:p-10 mb-8 sm:mb-12 transition-all">
      {/* iOS 2027 Ambient Glow Spheres */}
      <div className="glow-orb-cyan top-[-100px] right-[-40px] w-80 h-80 opacity-60" />
      <div className="glow-orb-purple bottom-[-80px] left-[-40px] w-72 h-72 opacity-50" />

      <div className="relative z-10 max-w-3xl">
        {hasLiveMatch && primaryLiveMatch ? (
          /* Real Live Match Card (ONLY if truly live!) */
          <div className="space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full dynamic-island border border-red-500/30 text-xs font-semibold text-red-400">
              <span className="w-2 h-2 rounded-full bg-red-500 ios-live-indicator" />
              <span>LIVE TRANSMISSION</span>
            </div>

            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
              {primaryLiveMatch.caption}
            </h1>

            {primaryLiveMatch.channelName && primaryLiveMatch.channelName !== 'No live match at the moment' && (
              <p className="text-sm sm:text-base text-slate-300 font-medium">
                {primaryLiveMatch.channelName}
              </p>
            )}

            <div className="pt-2">
              <button
                onClick={() => {
                  playPopSound();
                  onWatchChannel(primaryLiveMatch, 0);
                }}
                className="flex items-center gap-3 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-400 via-cyan-300 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold text-sm uppercase tracking-wider shadow-xl shadow-cyan-500/30 active:scale-95 transition-all duration-300"
              >
                <Play className="w-4 h-4 fill-black" />
                <span>Watch Live Now</span>
              </button>
            </div>
          </div>
        ) : (
          /* iOS 2027 Spatial Standby Glass Widget */
          <div className="space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full dynamic-island border border-cyan-500/20 text-xs font-semibold text-cyan-300">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>LIVE CRICKET STREAMING</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
              Pure Cricket Experience.
              <span className="block bg-gradient-to-r from-cyan-300 via-blue-400 to-purple-400 bg-clip-text text-transparent mt-1">
                Zero Delay. 100% Real Streams.
              </span>
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed">
              Streams link directly to the live transmission source. When matches begin, live players activate instantly with high-definition playback.
            </p>

            {/* iOS Glass Capsule Pill */}
            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-xl max-w-md flex items-center gap-3.5">
              <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 shrink-0">
                <Radio className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <div className="text-xs font-bold text-white tracking-wide">
                  Standby Mode // No Match Currently Live
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Feeds refresh automatically as soon as matches commence.
                </div>
              </div>
            </div>

            <div className="pt-1 flex items-center gap-3">
              <button
                onClick={() => {
                  playTapSound();
                  onExploreFeeds();
                }}
                className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-white/[0.08] hover:bg-white/[0.15] text-white text-xs font-bold border border-white/10 shadow-lg active:scale-95 transition-all duration-300"
              >
                <span>Browse All Channels</span>
                <ArrowRight className="w-4 h-4 text-cyan-400" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
