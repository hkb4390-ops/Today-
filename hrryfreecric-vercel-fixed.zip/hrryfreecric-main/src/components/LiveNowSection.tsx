import React from 'react';
import { ChannelItem } from '../types/cricket';
import { Radio, Play, Sparkles } from 'lucide-react';
import { playPopSound, playTapSound } from '../utils/audio';

interface LiveNowSectionProps {
  liveChannels: ChannelItem[];
  onWatchChannel: (channel: ChannelItem, streamIdx?: number) => void;
  onExploreFeeds: () => void;
}

export const LiveNowSection: React.FC<LiveNowSectionProps> = ({
  liveChannels,
  onWatchChannel,
  onExploreFeeds,
}) => {
  return (
    <section className="mb-10 sm:mb-14">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            LIVE NOW
          </h2>
        </div>

        {liveChannels.length > 0 && (
          <span className="px-3 py-1 rounded-full dynamic-island text-xs font-bold text-red-400 border border-red-500/30">
            {liveChannels.length} Active
          </span>
        )}
      </div>

      {/* Content */}
      {liveChannels.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {liveChannels.map((channel) => (
            <div
              key={channel.channelId}
              className="liquid-glass-card rounded-3xl p-5 flex flex-col justify-between group relative overflow-hidden"
            >
              <div>
                <div className="flex items-center justify-between text-xs mb-3">
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-500/20 text-red-400 font-bold border border-red-500/30">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 ios-live-indicator" />
                    <span>LIVE</span>
                  </div>
                  <span className="text-slate-400 font-mono text-[11px]">
                    Channel {channel.channelId}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-cyan-200 transition-colors">
                  {channel.caption}
                </h3>

                {channel.channelName && channel.channelName !== 'No live match at the moment' && (
                  <p className="mt-1 text-xs text-slate-300">
                    {channel.channelName}
                  </p>
                )}
              </div>

              <div className="mt-6">
                <button
                  onClick={() => {
                    playPopSound();
                    onWatchChannel(channel, 0);
                  }}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/20 active:scale-95 transition-all"
                >
                  <Play className="w-3.5 h-3.5 fill-black" />
                  <span>WATCH STREAM</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* iOS 2027 Empty State */
        <div className="rounded-3xl liquid-glass p-8 sm:p-12 text-center">
          <div className="max-w-sm mx-auto space-y-3">
            <div className="w-14 h-14 rounded-3xl bg-black/40 border border-white/10 flex items-center justify-center mx-auto text-slate-400 shadow-xl">
              <Radio className="w-7 h-7 text-cyan-400" />
            </div>

            <h3 className="text-base sm:text-lg font-black text-white">
              No live matches available right now.
            </h3>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Streams activate in real-time as soon as match broadcasts begin.
            </p>

            <div className="pt-2">
              <button
                onClick={() => {
                  playTapSound();
                  onExploreFeeds();
                }}
                className="px-5 py-2.5 rounded-2xl bg-white/[0.08] hover:bg-white/[0.15] text-white text-xs font-bold border border-white/10 active:scale-95 transition-all"
              >
                Browse Available Channels
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
