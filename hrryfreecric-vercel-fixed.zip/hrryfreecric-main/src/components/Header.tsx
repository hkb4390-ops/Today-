import React from 'react';
import { Radio, Search, Volume2, VolumeX, Sparkles } from 'lucide-react';
import { playTapSound } from '../utils/audio';

interface HeaderProps {
  activeLiveCount: number;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  activeTab: 'streams' | 'all';
  setActiveTab: (tab: 'streams' | 'all') => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeLiveCount,
  searchQuery,
  onSearchChange,
  activeTab,
  setActiveTab,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full pt-safe">
      <div className="max-w-5xl mx-auto px-4 py-3 sm:py-4">
        {/* Floating iOS 2027 Liquid Glass Capsule */}
        <div className="liquid-glass rounded-3xl px-4 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-3 sm:gap-6 shadow-2xl transition-all">
          
          {/* Logo & Brand */}
          <div 
            onClick={() => {
              playTapSound();
              setActiveTab('streams');
            }}
            className="flex items-center gap-2.5 cursor-pointer group select-none shrink-0"
          >
            <div className="relative">
              <div className="absolute -inset-1.5 bg-gradient-to-r from-cyan-500/40 via-blue-500/30 to-purple-500/40 rounded-2xl blur-md opacity-70 group-hover:opacity-100 transition duration-500" />
              <img
                src="https://i.postimg.cc/Dz1FXztx/file-00000000112082088dbc45fc024a2c70.png"
                alt="CRICHRRY"
                className="relative h-8 sm:h-9 w-auto object-contain rounded-xl"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-base sm:text-lg font-black tracking-wider bg-gradient-to-r from-white via-slate-100 to-cyan-300 bg-clip-text text-transparent">
                CRICHRRY
              </span>
            </div>
          </div>

          {/* Dynamic Island Status Capsule */}
          <div className="hidden md:flex items-center gap-2 px-3.5 py-1 rounded-full dynamic-island border border-white/10 text-xs font-medium">
            {activeLiveCount > 0 ? (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-80" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500" />
                </span>
                <span className="text-red-400 font-semibold tracking-wide">
                  {activeLiveCount} Live Match{activeLiveCount > 1 ? 'es' : ''}
                </span>
              </>
            ) : (
              <>
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                <span className="text-slate-300 font-normal">Real Feed Ready</span>
              </>
            )}
          </div>

          {/* Segmented Control Navigation */}
          <div className="flex items-center p-1 rounded-2xl bg-black/40 border border-white/[0.08] text-xs font-semibold">
            <button
              onClick={() => {
                playTapSound();
                setActiveTab('streams');
              }}
              className={`px-3 sm:px-4 py-1.5 rounded-xl transition-all duration-300 ${
                activeTab === 'streams'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow-md shadow-cyan-500/25 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Live
            </button>
            <button
              onClick={() => {
                playTapSound();
                setActiveTab('all');
              }}
              className={`px-3 sm:px-4 py-1.5 rounded-xl transition-all duration-300 ${
                activeTab === 'all'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow-md shadow-cyan-500/25 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Channels
            </button>
          </div>

          {/* Search & Sound Switcher */}
          <div className="flex items-center gap-2">
            {/* Search */}
            <div className="relative hidden sm:block w-36 lg:w-48">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl bg-black/40 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400/60 transition-all"
              />
            </div>

            {/* Sound Effects Toggle */}
            <button
              onClick={() => {
                onToggleSound();
                playTapSound();
              }}
              title={soundEnabled ? 'Haptic Sound: Enabled' : 'Haptic Sound: Muted'}
              className={`p-2 rounded-xl transition-all duration-300 ${
                soundEnabled 
                  ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30' 
                  : 'bg-white/[0.05] text-slate-500 border border-white/5 hover:text-slate-300'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
