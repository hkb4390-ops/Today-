import React, { useState } from 'react';
import { ChannelItem } from '../types/cricket';
import { isChannelLive } from '../services/streamingApi';
import { Play, Clock, Search, Radio, Sparkles } from 'lucide-react';
import { playPopSound, playTapSound } from '../utils/audio';

interface ChannelsGridProps {
  channels: ChannelItem[];
  onSelectChannel: (channel: ChannelItem, streamIdx?: number) => void;
  onShowOfflineCard: (channel: ChannelItem) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

export const ChannelsGrid: React.FC<ChannelsGridProps> = ({
  channels,
  onSelectChannel,
  onShowOfflineCard,
  searchQuery,
  onSearchChange,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'live' | 'upcoming'>('all');

  // Filter channels based on search & filterMode
  const filteredChannels = channels.filter((ch) => {
    const isLive = isChannelLive(ch);
    if (filterMode === 'live' && !isLive) return false;
    if (filterMode === 'upcoming' && isLive) return false;

    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      (ch.caption || '').toLowerCase().includes(q) ||
      (ch.channelName || '').toLowerCase().includes(q)
    );
  });

  const liveCount = channels.filter(isChannelLive).length;
  const upcomingCount = channels.length - liveCount;

  return (
    <section className="mb-14">
      {/* Header & Filter Segments */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
            Cricket Broadcast Network
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real matches synced directly with the streaming provider
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center p-1 rounded-2xl bg-black/40 border border-white/10 text-xs font-semibold">
          <button
            onClick={() => {
              playTapSound();
              setFilterMode('all');
            }}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              filterMode === 'all'
                ? 'bg-cyan-400 text-black font-extrabold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All ({channels.length})
          </button>
          <button
            onClick={() => {
              playTapSound();
              setFilterMode('live');
            }}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              filterMode === 'live'
                ? 'bg-cyan-400 text-black font-extrabold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Live ({liveCount})
          </button>
          <button
            onClick={() => {
              playTapSound();
              setFilterMode('upcoming');
            }}
            className={`px-3 py-1.5 rounded-xl transition-all ${
              filterMode === 'upcoming'
                ? 'bg-cyan-400 text-black font-extrabold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Upcoming ({upcomingCount})
          </button>
        </div>
      </div>

      {/* Grid */}
      {filteredChannels.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {filteredChannels.map((channel) => {
            const isLive = isChannelLive(channel);
            const streams = channel.streamsList || [];

            return (
              <div
                key={channel.channelId}
                className={`liquid-glass-card rounded-3xl p-5 flex flex-col justify-between group transition-all duration-300 ${
                  isLive ? 'border-cyan-500/30' : ''
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-3">
                    <span className="text-slate-400 font-mono text-[11px]">
                      Match Channel #{channel.channelId}
                    </span>

                    {isLive ? (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-500/20 text-red-400 font-bold border border-red-500/30 text-[11px]">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-500 ios-live-indicator" />
                        STREAMING LIVE
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/[0.04] text-slate-400 border border-white/5 text-[11px]">
                        Upcoming / Scheduled
                      </span>
                    )}
                  </div>

                  <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-cyan-200 transition-colors">
                    {channel.caption || `Channel ${channel.channelId}`}
                  </h3>

                  {isLive ? (
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {streams.map((st, sIdx) => (
                        <button
                          key={sIdx}
                          onClick={() => {
                            playPopSound();
                            onSelectChannel(channel, sIdx);
                          }}
                          className="text-[11px] font-mono px-2 py-0.5 rounded-lg bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-400 hover:text-black transition-all"
                        >
                          {st.caption.trim()}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <p className="mt-2 text-xs text-slate-400 line-clamp-1">
                      Stream link will be added when broadcast starts
                    </p>
                  )}
                </div>

                <div className="mt-6">
                  {isLive ? (
                    <button
                      onClick={() => {
                        playPopSound();
                        onSelectChannel(channel, 0);
                      }}
                      className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/20 active:scale-95 transition-all"
                    >
                      <Play className="w-3.5 h-3.5 fill-black" />
                      <span>Watch Live Stream</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        playTapSound();
                        onShowOfflineCard(channel);
                      }}
                      className="w-full flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-2xl bg-white/[0.05] hover:bg-white/[0.1] text-slate-300 hover:text-white border border-white/10 text-xs font-semibold active:scale-95 transition-all"
                    >
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>Match Schedule</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="rounded-3xl liquid-glass p-8 text-center max-w-sm mx-auto">
          <p className="text-sm font-bold text-slate-300">No matches found.</p>
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="mt-2 text-xs text-cyan-400 hover:underline"
            >
              Clear Search
            </button>
          )}
        </div>
      )}
    </section>
  );
};
