import { ChannelItem, ChannelsApiResponse, TokenResponse } from '../types/cricket';

export const DEFAULT_SN = '8cdR-LEJ8-U3FP-X6bc-6a3gc';

// Verified session token
let cachedToken: TokenResponse = {
  token: '970273a95d37ebdb72766e1c1ee1c70c16570997784f7e1nd5bdcde1058a46ee1c68e8e288b67c5845d7bf4010d2a27d9964a7a76d598752bde193e15037cef47',
  expiresAt: 1791572400,
  ipTag: '0a50c00f7202e596',
};

/**
 * Calculates the stream authentication key (pk) using the exact smartcric algorithm:
 * jako = token.substring(0, 47) + token.substring(48)
 */
export function computeJako(token: string): string {
  if (!token || token.length < 48) {
    return token || '';
  }
  return token.substring(0, 47) + token.substring(48);
}

/**
 * Fetches the active stream token.
 */
export async function fetchStreamingToken(): Promise<TokenResponse> {
  // 1. Try local server proxy
  try {
    const res = await fetch('/api/token', {
      headers: { Accept: 'application/json' },
    });
    if (res.ok) {
      const data: TokenResponse = await res.json();
      if (data && data.token && data.token.length > 80) {
        cachedToken = data;
        return data;
      }
    }
  } catch {
    // Continue
  }

  // 2. Direct fetch fallback
  try {
    const res = await fetch('https://smartcric.is/token.php');
    if (res.ok) {
      const data: TokenResponse = await res.json();
      if (data && data.token && data.token.length > 80) {
        cachedToken = data;
        return data;
      }
    }
  } catch {
    // Continue
  }

  return cachedToken;
}

/**
 * Fetches real channels list from the live API.
 * Prioritizes the direct upstream URL because it supports CORS across all browser environments.
 */
export async function fetchChannelsList(sn: string = DEFAULT_SN): Promise<ChannelsApiResponse> {
  const directUrl = `https://rest.smartcric.stream/mobile/channels/live/${encodeURIComponent(sn)}`;
  
  // 1. Direct fetch to rest.smartcric.stream (reliable CORS enabled by Cloudflare)
  try {
    const directRes = await fetch(directUrl, {
      headers: { 
        'Accept': 'application/json',
      },
      cache: 'no-store',
    });

    if (directRes.ok) {
      const data: ChannelsApiResponse = await directRes.json();
      if (data && Array.isArray(data.channelsList) && data.channelsList.length > 0) {
        return data;
      }
    }
  } catch (err) {
    console.warn('Direct fetch from rest.smartcric.stream failed, trying proxy:', err);
  }

  // 2. Server proxy fallback
  try {
    const res = await fetch(`/api/channels?sn=${encodeURIComponent(sn)}`, {
      headers: { Accept: 'application/json' },
      cache: 'no-store',
    });
    if (res.ok) {
      const json: ChannelsApiResponse = await res.json();
      if (json && Array.isArray(json.channelsList) && json.channelsList.length > 0) {
        return json;
      }
    }
  } catch (err) {
    console.warn('Proxy fetch failed:', err);
  }

  // 3. Fallback: return initial valid structure
  throw new Error('Failed to fetch live channels from stream API');
}

/**
 * Constructs the real HLS stream playlist URL.
 */
export function buildStreamUrl(
  fmsUrl: string,
  streamName: string,
  streamId: string | number,
  token: string
): string {
  const safeHost = fmsUrl || '63.scjustfor.info';
  const jako = computeJako(token || cachedToken.token);
  return `https://${safeHost}/mobile/${streamName}/playlist.m3u8?id=${streamId}&pk=${jako}`;
}

/**
 * Constructs the local proxy HLS stream playlist URL to bypass ISP blocking.
 */
export function buildStreamProxyUrl(
  fmsUrl: string,
  streamName: string,
  streamId: string | number,
  token: string
): string {
  const safeHost = fmsUrl || '63.scjustfor.info';
  const jako = computeJako(token || cachedToken.token);
  return `/api/stream?mode=master&host=${encodeURIComponent(safeHost)}&stream=${encodeURIComponent(streamName)}&id=${encodeURIComponent(streamId)}&pk=${encodeURIComponent(jako)}`;
}

/**
 * Determines if a channel currently has an active, playable live stream.
 * In the real smartcric API architecture, stream links are added when matches start.
 * A channel is LIVE if:
 * 1. streamsList exists and has one or more streams
 * 2. active flag is 1 or true
 */
export function isChannelLive(ch: ChannelItem): boolean {
  if (!ch) return false;

  const hasStreams = Array.isArray(ch.streamsList) && ch.streamsList.length > 0;
  const isActive = Number(ch.active) === 1 || String(ch.active) === '1' || String(ch.active) === 'true';

  return hasStreams || isActive;
}

/**
 * Checks if a channel has streams available.
 */
export function hasPlayableStreams(ch: ChannelItem): boolean {
  return Boolean(ch && Array.isArray(ch.streamsList) && ch.streamsList.length > 0);
}
