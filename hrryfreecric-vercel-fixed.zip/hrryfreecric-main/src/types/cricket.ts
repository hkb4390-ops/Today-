export interface StreamItem {
  streamName: string;
  streamId: string | number;
  caption: string;
}

export interface ChannelItem {
  active: number | string;
  caption: string;
  channelId: number;
  channelName: string;
  fmsUrl: string;
  status: string;
  streamsList?: StreamItem[];
}

export interface StopNotice {
  link: string;
  linkText: string;
  mainText: string;
  status: string;
  version: string;
}

export interface ChannelsApiResponse {
  channelsList: ChannelItem[];
  stop?: StopNotice[];
}

export interface TokenResponse {
  token: string;
  expiresAt: number;
  ipTag: string;
}

export interface StreamState {
  channel: ChannelItem;
  streamIndex: number;
  fmsUrl: string;
  streamUrl: string;
}
