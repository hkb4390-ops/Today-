/** Vercel serverless HLS proxy. Rewrites playlist URIs relative to the upstream playlist. */
export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Range');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET' && req.method !== 'HEAD') return res.status(405).send('Method not allowed');

  const q = req.query || {};
  const mode = String(q.mode || '');
  const target = typeof q.target === 'string' ? q.target : '';
  const host = typeof q.host === 'string' ? q.host : '63.scjustfor.info';
  const stream = typeof q.stream === 'string' ? q.stream : '';
  const id = typeof q.id === 'string' ? q.id : '';
  const pk = typeof q.pk === 'string' ? q.pk : '';
  const proxy = (m: string, url: string) => `/api/stream?mode=${m}&target=${encodeURIComponent(url)}`;

  // Reject malformed targets and non-HTTP URLs before fetching upstream content.
  const fetchUpstream = async (url: string) => {
    const parsed = new URL(url);
    if (parsed.protocol !== 'https:') throw new Error('Only HTTPS upstream URLs are supported');
    return fetch(parsed.toString(), { headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': '*/*' } });
  };

  try {
    if (mode === 'segment' || /\.ts(?:$|\?)/i.test(target)) {
      if (!target) return res.status(400).send('Missing segment target');
      const upstream = await fetchUpstream(target);
      if (!upstream.ok) return res.status(upstream.status).send(`Segment upstream returned ${upstream.status}`);
      res.setHeader('Content-Type', upstream.headers.get('content-type') || 'video/mp2t');
      res.setHeader('Cache-Control', 'public, max-age=30');
      const bytes = await upstream.arrayBuffer();
      return res.status(200).send(Buffer.from(bytes));
    }

    if (mode === 'child' || (target && /\.m3u8(?:$|\?)/i.test(target))) {
      if (!target) return res.status(400).send('Missing playlist target');
      const upstream = await fetchUpstream(target);
      if (!upstream.ok) return res.status(upstream.status).send(`Playlist upstream returned ${upstream.status}`);
      const body = await upstream.text();
      const base = new URL(target);
      const rewritten = body.split(/\r?\n/).map((line: string) => {
        const trimmed = line.trim();
        if (!trimmed) return line;
        // Rewrite URI attributes used by encryption keys or alternate renditions.
        if (trimmed.startsWith('#')) {
          return line.replace(/URI="([^"]+)"/g, (_match: string, uri: string) => {
            const absolute = new URL(uri, base).toString();
            const mode = /\.m3u8(?:$|\?)/i.test(absolute) ? 'child' : 'segment';
            return `URI="${proxy(mode, absolute)}"`;
          });
        }
        const absolute = new URL(trimmed, base).toString();
        return proxy(/\.m3u8(?:$|\?)/i.test(absolute) ? 'child' : 'segment', absolute);
      }).join('\n');
      res.setHeader('Content-Type', 'application/vnd.apple.mpegurl; charset=utf-8');
      res.setHeader('Cache-Control', 'no-store');
      return res.status(200).send(rewritten);
    }

    if (mode === 'master' || (stream && id && pk)) {
      if (!/^[a-zA-Z0-9.-]+$/.test(host) || host.includes('..')) return res.status(400).send('Invalid stream host');
      if (!stream || !/^[a-zA-Z0-9_-]+$/.test(stream) || !id || !pk) return res.status(400).send('Missing stream parameters');
      const upstreamUrl = `https://${host}/mobile/${encodeURIComponent(stream)}/playlist.m3u8?id=${encodeURIComponent(id)}&pk=${encodeURIComponent(pk)}`;
      const upstream = await fetchUpstream(upstreamUrl);
      if (!upstream.ok) return res.status(upstream.status).send(`Master playlist upstream returned ${upstream.status}`);
      const body = await upstream.text();
      const base = new URL(upstreamUrl);
      const rewritten = body.split(/\r?\n/).map((line: string) => {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) {
          if (trimmed.startsWith('#')) {
            return line.replace(/URI="([^"]+)"/g, (_match: string, uri: string) => {
              const absolute = new URL(uri, base).toString();
              const mode = /\.m3u8(?:$|\?)/i.test(absolute) ? 'child' : 'segment';
              return `URI="${proxy(mode, absolute)}"`;
            });
          }
          return line;
        }
        const absolute = new URL(trimmed, base).toString();
        return proxy(/\.m3u8(?:$|\?)/i.test(absolute) ? 'child' : 'segment', absolute);
      }).join('\n');
      res.setHeader('Content-Type', 'application/vnd.apple.mpegurl; charset=utf-8');
      res.setHeader('Cache-Control', 'no-store');
      return res.status(200).send(rewritten);
    }

    return res.status(400).send('Invalid stream request');
  } catch (err: any) {
    console.error('Stream proxy error:', err?.message || err);
    return res.status(502).send(`Stream proxy failed: ${err?.message || 'upstream request error'}`);
  }
}
