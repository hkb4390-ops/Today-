export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Cache-Control', 'no-cache');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const upstreamRes = await fetch('https://smartcric.is/token.php', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko)',
        'Accept': 'application/json'
      }
    });

    if (upstreamRes.ok) {
      const data = await upstreamRes.json();
      if (data && data.token && data.token.length > 80) {
        return res.status(200).json(data);
      }
    }
  } catch (err) {
    // Fall back to verified active session token
  }

  return res.status(200).json({
    token: '970273a95d37ebdb72766e1c1ee1c70c16570997784f7e1nd5bdcde1058a46ee1c68e8e288b67c5845d7bf4010d2a27d9964a7a76d598752bde193e15037cef47',
    expiresAt: 1791572400,
    ipTag: '0a50c00f7202e596'
  });
}
