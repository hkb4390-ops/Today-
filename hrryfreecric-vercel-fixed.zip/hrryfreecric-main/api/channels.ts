export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Cache-Control', 'no-cache');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const sn = req.query.sn || '8cdR-LEJ8-U3FP-X6bc-6a3gc';
  try {
    const upstreamUrl = `https://rest.smartcric.stream/mobile/channels/live/${encodeURIComponent(sn)}`;
    const apiRes = await fetch(upstreamUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko)',
        'Accept': 'application/json'
      }
    });

    if (apiRes.ok) {
      const data = await apiRes.json();
      return res.status(200).json(data);
    }
    return res.status(apiRes.status).json({ error: `Upstream error ${apiRes.status}` });
  } catch (err: any) {
    return res.status(502).json({ error: err.message || 'Failed to fetch upstream channels' });
  }
}
